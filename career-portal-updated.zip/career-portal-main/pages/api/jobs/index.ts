import type { NextApiRequest, NextApiResponse } from 'next';
import type { Prisma } from '@prisma/client';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  const { companyId, sourceId, search } = req.query;

  const where: Prisma.JobWhereInput = {};

  if (typeof companyId === 'string') {
    const parsed = Number(companyId);
    if (!Number.isNaN(parsed)) {
      where.companyId = parsed;
    }
  }

  if (typeof sourceId === 'string') {
    const parsed = Number(sourceId);
    if (!Number.isNaN(parsed)) {
      where.sourceId = parsed;
    }
  }

  if (typeof search === 'string' && search.trim().length > 0) {
    where.OR = [
      { title: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
      { location: { contains: search, mode: 'insensitive' } },
    ];
  }

  const jobs = await prisma.job.findMany({
    where,
    include: {
      company: true,
      source: true,
    },
    orderBy: { postedAt: 'desc' },
  });

  res.status(200).json({ jobs });
}
