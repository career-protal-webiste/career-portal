import type { NextApiRequest, NextApiResponse } from 'next';
import { upsertJob } from '../../../lib/db';
import {
  createFingerprint,
  roleMatches,
  inferExperience,
  normalize,
} from '../../../lib/jobs';

/**
 * Cron handler for pulling jobs from Workable public job feeds.
 *
 * Workable exposes a public endpoint at:
 *   https://apply.workable.com/api/v1/widget/accounts/{account}
 * which returns a JSON representation of all open jobs for a given
 * company. The response typically includes a `jobs` array. See the
 * Fantastic Jobs article for details【479957966343210†L84-L96】.
 *
 * Configure the ACCOUNTS array below with a human‑readable company name
 * and the Workable account slug. For example, if a company's job
 * application URL is https://apply.workable.com/acme/, then the
 * account slug is "acme".
 */
const ACCOUNTS: { company: string; account: string }[] = [
  // { company: 'Acme Corp', account: 'acme' },
];

export default async function handler(
  _req: NextApiRequest,
  res: NextApiResponse
) {
  let inserted = 0;

  for (const { company, account } of ACCOUNTS) {
    try {
      const url = `https://apply.workable.com/api/v1/widget/accounts/${encodeURIComponent(
        account
      )}`;
      const response = await fetch(url);
      if (!response.ok) continue;
      const data = (await response.json()) as any;
      const jobs: any[] = Array.isArray(data.jobs)
        ? data.jobs
        : Array.isArray(data)
        ? data
        : [];
      for (const j of jobs) {
        const title: string = j.title || '';
        if (!roleMatches(title)) continue;
        // Compose location from city/state/country if present
        const locParts = [j.city, j.state, j.country].filter(Boolean);
        const loc = locParts.length > 0 ? locParts.join(', ') : undefined;
        const jobUrl: string = j.url ||
          (j.shortcode
            ? `https://apply.workable.com/${account}/j/${j.shortcode}/`
            : '');
        const fingerprint = createFingerprint(company, title, loc, jobUrl);
        const record = {
          source: 'workable',
          source_id: j.id || j.shortcode || jobUrl,
          fingerprint,
          company,
          title,
          location: loc ?? null,
          remote: /remote/i.test(loc || ''),
          employment_type: j.employment_type || null,
          experience_hint: inferExperience(title, j.description),
          category: normalize(title).category,
          url: jobUrl,
          posted_at: j.created_at ? new Date(j.created_at) : new Date(),
          scraped_at: new Date(),
          description: j.description?.slice(0, 1200) ?? null,
          salary_min: j.salary?.min ?? null,
          salary_max: j.salary?.max ?? null,
          currency: j.salary?.currency ?? null,
          visa_tags: null,
        };
        await upsertJob(record);
        inserted += 1;
      }
    } catch (error) {
      console.error(`Failed to fetch Workable jobs for ${account}:`, error);
    }
  }
  res.status(200).json({ inserted });
}