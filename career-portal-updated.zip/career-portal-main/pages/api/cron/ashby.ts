import type { NextApiRequest, NextApiResponse } from 'next';
import { upsertJob } from '../../../lib/db';
import {
  createFingerprint,
  roleMatches,
  inferExperience,
  normalize,
} from '../../../lib/jobs';

/**
 * Cron handler for pulling jobs from Ashby public job boards.
 *
 * Ashby exposes a public endpoint at:
 *   https://api.ashbyhq.com/posting-api/job-board/{jobBoardName}?includeCompensation=false
 * which returns a list of published jobs for the specified company. No
 * authentication is required. See the Ashby docs for details【842622701020090†L49-L72】.
 *
 * To configure which companies you want to ingest, populate the BOARDS
 * array below with objects containing a human‑readable company name and
 * the job board name from their Ashby careers URL. For example, if a
 * company's Ashby careers page is https://jobs.ashbyhq.com/Acme, then the
 * job board name is "Acme".
 */
const BOARDS: { company: string; board: string }[] = [
  // { company: 'Acme Corp', board: 'Acme' },
];

export default async function handler(
  _req: NextApiRequest,
  res: NextApiResponse
) {
  let inserted = 0;

  for (const { company, board } of BOARDS) {
    try {
      const url = `https://api.ashbyhq.com/posting-api/job-board/${encodeURIComponent(
        board
      )}?includeCompensation=true`;
      const response = await fetch(url);
      if (!response.ok) continue;

      const data = (await response.json()) as any;
      const jobs = Array.isArray(data.jobs) ? data.jobs : [];

      for (const j of jobs) {
        const title: string = j.title || '';
        if (!roleMatches(title)) continue;

        // Derive location from the primary location field or fall back to the
        // postal address locality. If no location is provided, leave undefined.
        const loc =
          j.location ||
          j.address?.postalAddress?.addressLocality ||
          undefined;

        const jobUrl: string = j.jobUrl || j.applyUrl || '';

        const fingerprint = createFingerprint(company, title, loc, jobUrl);

        const record = {
          source: 'ashby',
          source_id: j.id || jobUrl, // fall back to URL if ID missing
          fingerprint,
          company,
          title,
          location: loc ?? null,
          remote: Boolean(j.isRemote),
          employment_type: j.employmentType ?? null,
          experience_hint: inferExperience(title, j.descriptionPlain),
          category: normalize(title).category,
          url: jobUrl,
          posted_at: j.publishedAt ? new Date(j.publishedAt) : new Date(),
          scraped_at: new Date(),
          description: j.descriptionPlain?.slice(0, 1200) ?? null,
          salary_min:
            j.compensation?.compensationTiers?.[0]?.components?.find(
              (c: any) => c.compensationType === 'Salary'
            )?.minValue ?? null,
          salary_max:
            j.compensation?.compensationTiers?.[0]?.components?.find(
              (c: any) => c.compensationType === 'Salary'
            )?.maxValue ?? null,
          currency:
            j.compensation?.compensationTiers?.[0]?.components?.find(
              (c: any) => c.compensationType === 'Salary'
            )?.currencyCode ?? null,
          visa_tags: null,
        };

        await upsertJob(record);
        inserted += 1;
      }
    } catch (error) {
      console.error(`Failed to fetch Ashby board ${board}:`, error);
    }
  }

  res.status(200).json({ inserted });
}