import type { NextApiRequest, NextApiResponse } from 'next';
import { upsertJob } from '../../../lib/db';
import {
  createFingerprint,
  roleMatches,
  inferExperience,
  normalize,
} from '../../../lib/jobs';

/**
 * Cron handler for pulling jobs from Recruitee public job feeds.
 *
 * The Recruitee Careers Site API exposes an endpoint at:
 *   https://{company}.recruitee.com/api/offers
 * which returns a JSON list of all public job offers. This handler loops
 * through a configured list of Recruitee subdomains, normalises each job and
 * stores it in the database. See the Fantastic Jobs article for more
 * details on the endpoint【479957966343210†L70-L77】.
 */
const ACCOUNTS: { company: string; subdomain: string }[] = [
  // { company: 'Example Co', subdomain: 'example' },
];

export default async function handler(
  _req: NextApiRequest,
  res: NextApiResponse
) {
  let inserted = 0;

  for (const { company, subdomain } of ACCOUNTS) {
    try {
      const url = `https://${subdomain}.recruitee.com/api/offers`;
      const response = await fetch(url);
      if (!response.ok) continue;
      const data = (await response.json()) as any;
      // The API returns an object with an "offers" array. Fall back to an empty
      // array if not present to avoid runtime errors.
      const offers: any[] = Array.isArray(data.offers)
        ? data.offers
        : Array.isArray(data) // some implementations return a raw array
        ? data
        : [];
      for (const offer of offers) {
        // Each offer typically contains title, id, slug and a list of locations.
        const title: string = offer.title || offer.name || '';
        if (!roleMatches(title)) continue;
        // Compose a display location from the first location entry, if present
        const locObj = offer.locations?.[0];
        const loc =
          locObj?.city && locObj?.country
            ? `${locObj.city}, ${locObj.country}`
            : locObj?.city || locObj?.country || undefined;

        // Derive the public URL. Recruitee jobs are usually accessible via
        // https://{subdomain}.recruitee.com/o/{slug}. Fall back to the offer.url
        // property if present.
        const jobUrl: string =
          offer.url ||
          (offer.slug
            ? `https://${subdomain}.recruitee.com/o/${offer.slug}`
            : '');

        const fingerprint = createFingerprint(company, title, loc, jobUrl);

        const record = {
          source: 'recruitee',
          source_id: offer.id || offer.slug || jobUrl,
          fingerprint,
          company,
          title,
          location: loc ?? null,
          remote: offer.remote || /remote/i.test(loc || ''),
          employment_type: offer.employment_type ?? null,
          experience_hint: inferExperience(title),
          category: normalize(title).category,
          url: jobUrl,
          posted_at: offer.updated_at
            ? new Date(offer.updated_at)
            : new Date(),
          scraped_at: new Date(),
          description: offer.description?.slice(0, 1200) ?? null,
          salary_min: offer.salary?.min ?? null,
          salary_max: offer.salary?.max ?? null,
          currency: offer.salary?.currency ?? null,
          visa_tags: null,
        };

        await upsertJob(record);
        inserted += 1;
      }
    } catch (error) {
      console.error(`Failed to fetch Recruitee offers for ${subdomain}:`, error);
    }
  }

  res.status(200).json({ inserted });
}