import type { NextApiResponse } from 'next';
import prisma from '../../lib/prisma';
import type { AuthedNextApiRequest } from '../../lib/middleware/withAuth';
import { withAuth } from '../../lib/middleware/withAuth';

interface SaveJobBody {
  jobId?: number;
}

async function handler(req: AuthedNextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  const body: SaveJobBody = req.body ?? {};
  const jobId = typeof body.jobId === 'number' ? body.jobId : Number(body.jobId);

  if (!jobId || Number.isNaN(jobId)) {
    res.status(400).json({ error: 'A valid jobId is required' });
    return;
  }

  const job = await prisma.job.findUnique({ where: { id: jobId } });
  if (!job) {
    res.status(404).json({ error: 'Job not found' });
    return;
  }

  const savedJob = await prisma.savedJob.upsert({
    where: {
      userId_jobId: {
        userId: req.user.id,
        jobId,
      },
    },
    update: {
      savedAt: new Date(),
    },
    create: {
      userId: req.user.id,
      jobId,
    },
    include: {
      job: {
        include: {
          company: true,
          source: true,
        },
      },
    },
  });

  res.status(200).json({ savedJob });
}

export default withAuth(handler);
