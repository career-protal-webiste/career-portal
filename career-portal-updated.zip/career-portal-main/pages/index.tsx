import { GetServerSideProps } from 'next';
import Layout from '../components/Layout';
import JobCard, { Job } from '../components/JobCard';
import { getJobs } from '../lib/db';

interface HomeProps {
  jobs: Job[];
}

export default function Home({ jobs }: HomeProps) {
  return (
    <Layout
      title="Latest Opportunities"
      description="Curated engineering, product, analytics, and data roles sourced from trusted company job boards."
    >
      <section id="latest" className="space-y-6">
        {jobs.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center">
            <h2 className="text-lg font-semibold text-slate-800">No roles available just yet</h2>
            <p className="mt-2 text-sm text-slate-500">
              We refresh the feed every few minutes. Bookmark this page or subscribe to get notified when something new is posted.
            </p>
          </div>
        ) : (
          <div className="grid gap-4">
            {jobs.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        )}
      </section>
      <section id="about" className="mt-16 space-y-4 rounded-2xl bg-white p-8 shadow-sm">
        <h2 className="text-xl font-semibold text-slate-900">About this portal</h2>
        <p className="text-sm leading-relaxed text-slate-600">
          This portal aggregates openings directly from company applicant tracking systems like Lever and Greenhouse. Listings are
          deduplicated and enriched with metadata such as employment type and location so you can scan opportunities faster.
        </p>
        <p className="text-sm leading-relaxed text-slate-600">
          Looking for something specific? Filter by keywords in your browser, save interesting links, and check back weekly for
          new roles. We are working on saved searches and email notifications next.
        </p>
      </section>
    </Layout>
  );
}

export const getServerSideProps: GetServerSideProps<HomeProps> = async () => {
  try {
    const jobs = await getJobs(100);
    return { props: { jobs } };
  } catch (error) {
    console.error('Failed to load jobs', error);
    return { props: { jobs: [] } };
  }
};
