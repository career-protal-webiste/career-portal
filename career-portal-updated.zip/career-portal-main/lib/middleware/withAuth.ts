import type { NextApiHandler, NextApiRequest, NextApiResponse } from 'next';
import { getSession, type SessionUser } from '../auth';

export interface AuthedNextApiRequest extends NextApiRequest {
  user: SessionUser;
}

type AuthedHandler = (req: AuthedNextApiRequest, res: NextApiResponse) => unknown | Promise<unknown>;

export function withAuth(handler: AuthedHandler): NextApiHandler {
  return async function authWrapper(req, res) {
    const session = await getSession(req);

    if (!session) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    (req as AuthedNextApiRequest).user = session;

    return handler(req as AuthedNextApiRequest, res);
  };
}
