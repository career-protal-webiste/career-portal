import type { NextApiRequest } from 'next';
import prisma from './prisma';

export interface SessionUser {
  id: number;
  email: string;
  name: string | null;
}

function extractToken(req: NextApiRequest): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring('Bearer '.length).trim();
  }

  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) {
    return null;
  }

  const sessionCookie = cookieHeader
    .split(';')
    .map((part) => part.trim())
    .find((part) => part.startsWith('session_token='));

  if (!sessionCookie) {
    return null;
  }

  const [, token] = sessionCookie.split('=');
  return token ?? null;
}

export async function getSession(req: NextApiRequest): Promise<SessionUser | null> {
  const token = extractToken(req);
  if (!token) {
    return null;
  }

  const user = await prisma.user.findUnique({
    where: { sessionToken: token },
    select: {
      id: true,
      email: true,
      name: true,
    },
  });

  if (!user) {
    return null;
  }

  return user;
}
