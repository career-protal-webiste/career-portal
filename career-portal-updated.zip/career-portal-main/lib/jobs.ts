import crypto from 'crypto';

/**
 * Create a fingerprint from a combination of company, title, location and URL.
 *
 * The old implementation included the ATS source and job ID which only
 * prevented duplicates within a single provider. By reducing the
 * fingerprint inputs to the user‐visible fields (company, title,
 * location and URL) we can detect duplicates across different ATS
 * providers. For example, the same job posted on Lever and Greenhouse will
 * generate the same fingerprint and therefore only be stored once in the
 * database.
 *
 * The URL is normalised by removing any query parameters and lowering
 * case to avoid mismatches due to tracking parameters. All string
 * components are trimmed and converted to lowercase before hashing.
 */
export function createFingerprint(
  company: string,
  title: string,
  loc?: string,
  url?: string
) {
  // normalise the URL by stripping query params and converting to lower case
  const normalisedUrl = (url ?? '')
    .split('?')[0]
    .toLowerCase()
    .trim();
  const canon = [
    (company ?? '').toLowerCase().trim(),
    (title ?? '').toLowerCase().trim(),
    (loc ?? '').toLowerCase().trim(),
    normalisedUrl,
  ].join('|');

  return crypto.createHash('sha256').update(canon).digest('hex');
}

const ROLE_KEYWORDS: Record<string, RegExp[]> = {
  apm: [/product manager/i, /apm/i, /associate product/i, /product analyst/i],
  analytics: [/data analyst/i, /business analyst/i, /analytics/i],
  data: [/data engineer/i, /etl/i, /data platform/i],
  sde: [/software engineer/i, /swe/i, /backend/i, /full stack/i, /frontend/i],
  bio: [/biomedical/i, /bioinformatics/i, /clinical data/i, /medical devices/i],
};

export function roleMatches(title: string) {
  return Object.values(ROLE_KEYWORDS).some((patterns) =>
    patterns.some((p) => p.test(title))
  );
}

export function inferExperience(title: string, description?: string) {
  const text = `${title} ${description ?? ''}`;
  const match = text.match(/(\d)\s*-\s*(\d)\+?\s*years?/i);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  if (/intern|new grad|junior|associate/i.test(text)) return '0-1';
  return undefined;
}

export function normalize(title: string) {
  for (const key of Object.keys(ROLE_KEYWORDS)) {
    if (ROLE_KEYWORDS[key].some((p) => p.test(title))) {
      return { category: key };
    }
  }
  return { category: undefined };
}
