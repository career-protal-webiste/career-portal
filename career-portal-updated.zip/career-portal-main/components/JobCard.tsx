export interface Job {
  id: number;
  source: string;
  source_id: string;
  fingerprint: string;
  company: string;
  title: string;
  location?: string | null;
  remote?: boolean | null;
  employment_type?: string | null;
  experience_hint?: string | null;
  category?: string | null;
  url: string;
  posted_at: string;
  description?: string | null;
}

interface JobCardProps {
  job: Job;
}

const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });

function formatPostedAt(postedAt: string) {
  const postedDate = new Date(postedAt);
  if (Number.isNaN(postedDate.getTime())) {
    return postedAt;
  }

  const now = Date.now();
  const diffMs = postedDate.getTime() - now;
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (Math.abs(diffDays) >= 7) {
    return postedDate.toLocaleDateString();
  }

  if (Math.abs(diffDays) >= 1) {
    return rtf.format(diffDays, 'day');
  }

  const diffHours = Math.round(diffMs / (1000 * 60 * 60));
  if (Math.abs(diffHours) >= 1) {
    return rtf.format(diffHours, 'hour');
  }

  const diffMinutes = Math.round(diffMs / (1000 * 60));
  return rtf.format(diffMinutes, 'minute');
}

export function JobCard({ job }: JobCardProps) {
  const locationLabel = job.location?.trim() || (job.remote ? 'Remote' : undefined);

  return (
    <article className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg focus-within:-translate-y-0.5 focus-within:shadow-lg">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            <a
              href={job.url}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              {job.title}
            </a>
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            {job.company}
            {locationLabel ? <span className="text-slate-400"> · {locationLabel}</span> : null}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs font-medium uppercase tracking-wide text-slate-500">
            {job.employment_type ? (
              <span className="rounded-full bg-slate-100 px-3 py-1 text-slate-700">{job.employment_type}</span>
            ) : null}
            {job.remote ? (
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-emerald-700">Remote friendly</span>
            ) : null}
            {job.category ? (
              <span className="rounded-full bg-indigo-100 px-3 py-1 text-indigo-700">{job.category}</span>
            ) : null}
            {job.experience_hint ? (
              <span className="rounded-full bg-orange-100 px-3 py-1 text-orange-700">{job.experience_hint} yrs</span>
            ) : null}
          </div>
        </div>
        <span className="shrink-0 whitespace-nowrap text-xs font-medium text-slate-500">{formatPostedAt(job.posted_at)}</span>
      </div>
      {job.description ? (
        <p className="mt-4 text-sm leading-relaxed text-slate-600">
          {job.description.length > 240 ? `${job.description.slice(0, 237)}...` : job.description}
        </p>
      ) : null}
    </article>
  );
}

export default JobCard;
