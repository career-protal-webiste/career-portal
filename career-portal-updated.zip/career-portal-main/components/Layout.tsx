import Head from 'next/head';
import { ReactNode } from 'react';

interface LayoutProps {
  title: string;
  description?: string;
  children: ReactNode;
}

export function Layout({ title, description, children }: LayoutProps) {
  const siteTitle = `${title} · Career Portal`;

  return (
    <>
      <Head>
        <title>{siteTitle}</title>
        {description ? <meta name="description" content={description} /> : null}
      </Head>
      <div className="min-h-screen bg-slate-50 text-slate-900">
        <header className="bg-white border-b">
          <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-indigo-500">Career Portal</p>
              <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
              {description ? (
                <p className="mt-2 max-w-2xl text-sm text-slate-600">{description}</p>
              ) : null}
            </div>
            <nav className="hidden text-sm font-medium text-slate-500 sm:flex sm:space-x-6">
              <a className="transition hover:text-slate-900" href="#latest">
                Latest roles
              </a>
              <a className="transition hover:text-slate-900" href="#saved">
                Saved jobs
              </a>
              <a className="transition hover:text-slate-900" href="#about">
                About
              </a>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-5xl px-6 py-10">{children}</main>
        <footer className="border-t bg-white">
          <div className="mx-auto flex max-w-5xl flex-col items-start justify-between gap-4 px-6 py-6 text-sm text-slate-500 sm:flex-row">
            <p>&copy; {new Date().getFullYear()} Career Portal. All rights reserved.</p>
            <div className="flex flex-wrap gap-x-4 gap-y-2">
              <a className="transition hover:text-slate-900" href="/privacy">
                Privacy
              </a>
              <a className="transition hover:text-slate-900" href="/terms">
                Terms
              </a>
              <a className="transition hover:text-slate-900" href="mailto:hello@example.com">
                Contact
              </a>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}

export default Layout;
