# Building your Vercel-hosted job portal without using a terminal

These instructions explain how to build and deploy the careers portal completely through web interfaces. You won’t run any commands on your laptop; instead you will click buttons and copy-paste code using GitHub and Vercel’s dashboards. The portal will fetch jobs from Lever and Greenhouse via their public APIs and display them on a Next.js site hosted on Vercel. Later you can extend it with more sources, authentication and subscriptions.

> **Reminder:** Vercel cron jobs must define a path (starting with `/`) and a cron expression schedule. Cron jobs only run in production deployments.

## 1. Create a new project on Vercel

1. Open [vercel.com](https://vercel.com) in your browser and sign in (or create an account).
2. Click **New Project → Start from a Template → Next.js**. Vercel will ask for permission to create a repository on your GitHub account.
3. Name your project (for example `career-portal`) and choose a GitHub repository location. Vercel will create a new repository with starter code and connect it automatically.
4. Wait a moment while Vercel deploys the default Next.js app to your personal domain (e.g. `https://career-portal.vercel.app`).

At this point you have a working Next.js app in GitHub and a Vercel project connected to it.

## 2. Provision a database

1. In the Vercel dashboard, open your project. Go to **Storage → Add → PostgreSQL**. Follow the prompts to create a database.
2. Once created, copy the connection string (looks like `postgres://USER:PASSWORD@HOST:PORT/DATABASE`). You will set this as an environment variable.
3. In your project’s Vercel settings, under **Environment Variables**, add a variable named `POSTGRES_URL` (or `DATABASE_URL` if you prefer) and paste the connection string as its value.

## 3. Edit your GitHub repository online

You’ll now add code files directly in GitHub. Navigate to your new repository on github.com. For each file below, click **Add file → Create new file**, paste the content, and commit it to the main branch.

### 3.1 Add a database helper (`lib/db.ts`)

Create a new folder called `lib` (if it doesn’t exist) and within it a file named `db.ts`. Paste the following:

```ts
import { sql } from '@vercel/postgres';

// Ensure the jobs table exists
export async function createJobsTable() {
  await sql`
    CREATE TABLE IF NOT EXISTS jobs (
      id SERIAL PRIMARY KEY,
      source TEXT NOT NULL,
      source_id TEXT NOT NULL,
      fingerprint TEXT UNIQUE NOT NULL,
      company TEXT NOT NULL,
      title TEXT NOT NULL,
      location TEXT,
      remote BOOLEAN,
      employment_type TEXT,
      experience_hint TEXT,
      category TEXT,
      url TEXT NOT NULL,
      posted_at TIMESTAMP NOT NULL,
      scraped_at TIMESTAMP DEFAULT NOW(),
      description TEXT,
      salary_min INTEGER,
      salary_max INTEGER,
      currency TEXT,
      visa_tags TEXT[]
    );
  `;

  await sql`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_source_sourceid ON jobs(source, source_id);
  `;
}

// Insert a job if it doesn’t already exist
export async function upsertJob(job: any) {
  await createJobsTable();
  await sql`
    INSERT INTO jobs (source, source_id, fingerprint, company, title, location,
      remote, employment_type, experience_hint, category, url, posted_at, scraped_at,
      description, salary_min, salary_max, currency, visa_tags)
    VALUES (
      ${job.source}, ${job.source_id}, ${job.fingerprint}, ${job.company}, ${job.title},
      ${job.location}, ${job.remote}, ${job.employment_type}, ${job.experience_hint},
      ${job.category}, ${job.url}, ${job.posted_at}, ${job.scraped_at ?? new Date()},
      ${job.description}, ${job.salary_min}, ${job.salary_max}, ${job.currency}, ${job.visa_tags}
    )
    ON CONFLICT (fingerprint) DO NOTHING;
  `;
}

// Fetch jobs for the homepage
export async function getJobs(limit: number = 50) {
  await createJobsTable();
  const { rows } = await sql`SELECT * FROM jobs ORDER BY posted_at DESC LIMIT ${limit}`;
  return rows;
}
```

### 3.2 Add job utilities (`lib/jobs.ts`)

Create `lib/jobs.ts` with helper functions to categorize roles and deduplicate jobs:

```ts
import crypto from 'crypto';

// Create a fingerprint to detect duplicates across different ATS providers
export function createFingerprint(source: string, id: string, team?: string, loc?: string, url?: string) {
  const canon = [source, id, (team ?? '').toLowerCase(), (loc ?? '').toLowerCase(), (url ?? '').toLowerCase()].join('|');
  return crypto.createHash('sha256').update(canon).digest('hex');
}

// Simple role matcher: adjust keywords as needed
const ROLE_KEYWORDS = {
  apm: [/product manager/i, /apm/i, /associate product/i, /product analyst/i],
  analytics: [/data analyst/i, /business analyst/i, /analytics/i],
  data: [/data engineer/i, /etl/i, /data platform/i],
  sde: [/software engineer/i, /swe/i, /backend/i, /full stack/i, /frontend/i],
  bio: [/biomedical/i, /bioinformatics/i, /clinical data/i, /medical devices/i]
};

export function roleMatches(title: string) {
  return Object.values(ROLE_KEYWORDS).some(patterns => patterns.some(p => p.test(title)));
}

// Parse years of experience from title/description; returns a string like "0-1", "1-2", etc.
export function inferExperience(title: string, description?: string) {
  const text = `${title} ${description ?? ''}`;
  const match = text.match(/(\d)\s*-\s*(\d)\+?\s*years?/i);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  if (/intern|new grad|junior|associate/i.test(text)) return '0-1';
  return undefined;
}

// Normalize role to one of the defined categories
export function normalize(title: string) {
  for (const key of Object.keys(ROLE_KEYWORDS)) {
    if (ROLE_KEYWORDS[key as keyof typeof ROLE_KEYWORDS].some(p => p.test(title))) {
      return { category: key };
    }
  }
  return { category: undefined };
}
```

### 3.3 Create API routes for scheduled scraping

Inside the `pages/api` directory (create it if it doesn’t exist), make a folder `cron`. Inside `cron`, create a file named `lever.ts` and paste the following code:

```ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { upsertJob } from '../../../lib/db';
import { createFingerprint, roleMatches, inferExperience, normalize } from '../../../lib/jobs';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const companies = ['databricks','snowflake','notion','hubspot']; // add more accounts as desired
  let inserted = 0;

  for (const company of companies) {
    const response = await fetch(`https://api.lever.co/v0/postings/${company}?mode=json`);
    if (!response.ok) continue;
    const postings = await response.json();

    for (const p of postings) {
      const title = p.text || p.title || '';
      if (!roleMatches(title)) continue;

      const fingerprint = createFingerprint('lever', p.id, p.categories?.team, p.categories?.location, p.hostedUrl);
      const job = {
        source: 'lever',
        source_id: p.id,
        fingerprint,
        company: p.categories?.team || p.company || company,
        title,
        location: p.categories?.location,
        remote: /remote/i.test(p.categories?.location || '') || p.workplaceType === 'remote',
        employment_type: p.categories?.commitment,
        experience_hint: inferExperience(title, p.descriptionPlain),
        category: normalize(title).category,
        url: p.hostedUrl,
        posted_at: new Date(p.createdAt),
        description: p.descriptionPlain?.slice(0, 1200)
      };

      await upsertJob(job);
      inserted++;
    }
  }

  res.status(200).json({ inserted });
}
```

Create another file `greenhouse.ts` in the same `cron` folder:

```ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { upsertJob } from '../../../lib/db';
import { createFingerprint, roleMatches, inferExperience, normalize } from '../../../lib/jobs';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Add the board tokens for companies you want to scrape (found in their Greenhouse job board URL)
  const boards: { company: string; token: string }[] = [
    { company: 'Example Co', token: 'example' },
  ];

  let inserted = 0;
  for (const board of boards) {
    const response = await fetch(`https://boards-api.greenhouse.io/v1/boards/${board.token}/jobs`);
    if (!response.ok) continue;
    const data = await response.json();

    for (const job of data.jobs) {
      const title: string = job.title;
      if (!roleMatches(title)) continue;
      const fingerprint = createFingerprint('greenhouse', String(job.id), undefined, job.location?.name, job.absolute_url);
      const record = {
        source: 'greenhouse',
        source_id: String(job.id),
        fingerprint,
        company: board.company,
        title,
        location: job.location?.name,
        remote: /remote/i.test(job.location?.name || ''),
        employment_type: undefined,
        experience_hint: inferExperience(title),
        category: normalize(title).category,
        url: job.absolute_url,
        posted_at: new Date(job.updated_at),
        description: undefined
      };

      await upsertJob(record);
      inserted++;
    }
  }

  res.status(200).json({ inserted });
}
```

These routes fetch jobs from Lever and Greenhouse using their public APIs, categorise them with our helper functions and upsert them into the `jobs` table.  The `createFingerprint` helper has been updated to compute a hash from the combination of company, title, location and URL rather than the ATS source and job ID.  This means the same job appearing on multiple providers (for example a company posts the same role on Lever and Greenhouse) will only be stored once in your database.  If you see duplicates, double‑check that the company name, title and URL match exactly across providers.

### 3.3.1 Add more providers (Ashby, Recruitee, Workable)

Many modern applicant tracking systems offer unauthenticated public feeds.  To include jobs from **Ashby**, **Recruitee** and **Workable**, the project now includes three additional API routes:

- `pages/api/cron/ashby.ts` – fetches jobs from Ashby careers boards.  Populate the `BOARDS` array in that file with objects like `{ company: 'Acme Corp', board: 'Acme' }`, where `board` is the job board name from the Ashby careers URL (e.g. `https://jobs.ashbyhq.com/Acme`).
- `pages/api/cron/recruitee.ts` – fetches jobs from Recruitee.  Add entries to the `ACCOUNTS` array with your company name and the subdomain of your Recruitee careers site, e.g. `{ company: 'Acme Corp', subdomain: 'acme' }` for `https://acme.recruitee.com`.
- `pages/api/cron/workable.ts` – fetches jobs from Workable.  Configure the `ACCOUNTS` array with the company name and the Workable account slug, e.g. `{ company: 'Acme Corp', account: 'acme' }` for `https://apply.workable.com/acme/`.

Each handler normalises the job data, filters for relevant roles using `roleMatches`, computes a cross‑provider fingerprint and upserts the job.  The same `jobs` table and `upsertJob` function are used for all providers.

### 3.4 Schedule the cron jobs

In the root of your repository, add a file called `vercel.json` with cron configuration. Cron expressions use UTC and follow standard syntax; below we run each fetcher every 15 minutes:

```json
{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "crons": [
    { "path": "/api/cron/lever", "schedule": "*/15 * * * *" },
    { "path": "/api/cron/greenhouse", "schedule": "*/15 * * * *" }
    ,{ "path": "/api/cron/ashby", "schedule": "*/20 * * * *" }
    ,{ "path": "/api/cron/recruitee", "schedule": "*/20 * * * *" }
    ,{ "path": "/api/cron/workable", "schedule": "*/20 * * * *" }
  ]
}
```

When you deploy, Vercel will create cron jobs that invoke `/api/cron/lever` and `/api/cron/greenhouse` on that schedule.
Any additional cron entries (e.g. Ashby, Recruitee and Workable) will also be scheduled automatically.

### 3.5 Modify the homepage to list jobs

Edit `pages/index.tsx` (created by the template) to display the jobs from your database. Replace its contents with:

```tsx
import { getJobs } from '../lib/db';

export default function Home({ jobs }: { jobs: any[] }) {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">Latest Jobs</h1>
      <ul className="space-y-2">
        {jobs.map(job => (
          <li key={job.id} className="border rounded-lg p-4 hover:bg-gray-50">
            <a href={job.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 font-semibold">
              {job.title}
            </a>
            <p className="text-sm text-gray-600">{job.company} — {job.location || 'Remote'}</p>
            <p className="text-xs text-gray-500">Posted {new Date(job.posted_at).toLocaleDateString()}</p>
          </li>
        ))}
      </ul>
    </main>
  );
}

export async function getServerSideProps() {
  const jobs = await getJobs(100);
  return { props: { jobs } };
}
```

This page fetches the latest jobs from the database on every request and renders them.

## 4. Commit and deploy

After you’ve created or edited all the files above in GitHub’s web editor, Vercel will automatically rebuild and redeploy your project. You can follow the build logs in the Vercel dashboard. Once the deployment succeeds, your site should display “Latest Jobs” and an empty list (the first time). Within about 15 minutes the cron jobs will run and start populating the database with jobs.

## 5. What happens next?

- The Lever and Greenhouse fetchers will run every 15 minutes, query the public APIs and insert new jobs into your database. They skip duplicates by using a fingerprint and unique constraints.
- You can expand the `companies` array in `lever.ts` and the `boards` array in `greenhouse.ts` to include more employers. For Greenhouse, find a company’s board token in their Greenhouse URL (e.g. `https://boards.greenhouse.io/<token>`).
- To support Ashby or Recruitee later, add similar files (e.g. `ashby.ts`, `recruitee.ts`) using the public endpoints documented in their APIs.
- If you decide to add user login and subscriptions later, you can integrate Auth.js (NextAuth v5) as described previously.

By following these steps entirely through GitHub and Vercel’s web UIs, you can deploy a working careers portal without installing anything locally. The project uses public job board APIs, scheduled serverless functions and a cloud database to deliver fresh job listings.
