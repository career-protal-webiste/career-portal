# Database Schema

```mermaid
erDiagram
    COMPANY ||--o{ JOB : posts
    JOB_SOURCE ||--o{ JOB : originates
    USER ||--o{ SAVED_JOB : saves
    JOB ||--o{ SAVED_JOB : "is saved in"

    COMPANY {
        Int id PK
        String name
        String website
        String description
        DateTime created_at
        DateTime updated_at
    }

    JOB_SOURCE {
        Int id PK
        String name
        String url
        DateTime created_at
        DateTime updated_at
    }

    JOB {
        Int id PK
        String title
        String location
        Boolean remote
        DateTime posted_at
        String employment_type
        String description
        Int company_id FK
        Int source_id FK
        DateTime created_at
        DateTime updated_at
    }

    USER {
        Int id PK
        String email
        String name
        String password_hash
        String session_token
        DateTime created_at
        DateTime updated_at
    }

    SAVED_JOB {
        Int id PK
        Int user_id FK
        Int job_id FK
        DateTime saved_at
    }
```

## Entity Notes

- **companies** represent organizations that post openings. Each company may have many jobs.
- **job_sources** track the origin of listings (for example, "LinkedIn" or an internal board) and can be attached to multiple jobs.
- **jobs** belong to both a company and a source. Metadata such as location, employment type, and remote status make the listings filterable.
- **users** authenticate with the portal and maintain a `session_token` used by the API layer for lightweight session validation.
- **saved_jobs** links users to the jobs they bookmark. A user can save many jobs, but each job can only be saved once per user.
- Audit fields (`created_at`, `updated_at`) support change tracking across entities.
